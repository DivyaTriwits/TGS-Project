    <!-- Start footer area -->
    <footer id="footer" class="site-footer">
        <div class="footer-top-area">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <h5 align="center">The Global Scholarship portal is aimed at facilitating single-window processing of educational scholarship applications for various schemes given by sponsors and guides aspirants to apply for applications of wide-ranging Scholarships.</h5>
                        <div class="single-faq-content">
                               <!--<h5> The Global Scholarship portal aimed at facilitating single-window processing of -->
                               <!--educational scholarship application for various schemes given by sponsors and guides aspirants to -->
                               <!--make apply of applications for wide-ranging Scholarships.</h5>-->
                               <!--<h6>- Nnamdi Azikiwe</h6>-->
                         </div>
                    </div><!--/.col-lg-9-->
                </div><!--/.row-->
            </div><!--/.container-->
        </div><!--/.footer-top-area-->

        <!-- Start footer widgets area -->
        <div class="footer-widgets-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-6 col-6">
                        <div class="footer-widget">
                            <h4 class="footer-title">Quick Links</h4>
                            <ul class="footer-widget-list list-unstyled">
                                <li><a href="<?php echo base_url();?>">Home</a></li>
                                <li><a href="<?php echo base_url('faq');?>">FAQ</a></li>
                                <li><a href="<?php echo base_url('contact-us');?>">Contact Us</a></li>
                                <li><a href="<?php echo base_url('#learning-section');?>">Apply For Scholarship</a></li>
                                <li><a href="<?php echo base_url('influencer-login');?>">Become An Influencer</a></li>
                                <!--<li><a href="<?php echo base_url('login');?>">Add Scholarship</a></li>-->
                                <li>
                                    <!-- Start of CuterCounter Code -->
                                    <a href="https://www.cutercounter.com/" target="_blank"><img src="https://www.cutercounter.com/hits.php?id=gucfoan&nd=6&style=5" border="0" alt="free counter"></a>
                                    <!-- End of CuterCounter Code -->
                                </li>
                            </ul>
                        </div><!--/.footer-widget-->
                        
                    </div><!--/.col-lg-3-->
                    <div class="col-lg-3 col-sm-6 col-6">
                        <div class="footer-widget">
                            <h4 class="footer-title">Sales</h4>
                            <ul class="footer-widget-list list-unstyled ">
                            <li><a style="text-transform: lowercase;" href="mailto:sales@theglobalscholarship.org"><i class="fa fa-envelope" style="font-size:16px"></i> sales@theglobalscholarship.org</a></li>
                            <!--<li><a href="tel:+918892278892"><i class="fa fa-phone" style="font-size:16px"></i> +91-8892278892</a></li>-->
                            <li><a href="tel:+919620030302"><i class="fa fa-phone" style="font-size:16px"></i> +91-9620030302</a></li>
                            
                            </ul>
                        </div><!--/.footer-widget-->
                        <div class="footer-widget">
                            <h4 class="footer-title">Support</h4>
                            <ul class="footer-widget-list list-unstyled">
                            <li><a style="text-transform: lowercase;" href="mailto:support@theglobalscholarship.org"><i class="fa fa-envelope" style="font-size:16px"></i> support@theglobalscholarship.org</a></li>
                            <li><a href="tel:+919916056303"><i class="fa fa-phone" style="font-size:16px"></i> +91-9916056303</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-6">
                        <!--<div class="col-lg-3 col-sm-12">-->
                         <div class="footer-widget">
                            <h4 class="footer-title">Office Timing</h4>
                            <ul class="footer-widget-list list-unstyled">
                            <li><i class="fa fa-calendar" style="font-size:16px"></i> Monday - Saturday</li>
                            <li><i class="fa fa-clock-o" style="font-size:16px"></i> 10:00 AM - 6:00 PM</li>
                             <li><i class="fa fa-calendar" style="font-size:16px"></i> Sunday - Holiday</li>
                            </ul>
                        </div>
                       
                    </div><!--/.col-lg-6-->
                     <div class="col-lg-3 col-sm-6 col-6">
                     <div class="footer-newsletter footer-widget">
                            <h4 class="footer-title">Newsletter</h4>
                            <p>Do you want to get notified about new Scholarships subscribe now</p>
                            <form class="newsletter-form" method="post" action="<?php echo base_url('newsletter-subscription');?>">
                                <div class="form-group">
                                      <input class="form-control" name="news" type="email" placeholder="Your email address" required style="color:#fff;width: 100%;" >
                                    <button type="submit" class="btn btn-default btn-primary"style="width: 80px;padding-left: 10px;font-size: 10px">Subscribe</button>
                                </div>
                            </form>
                            <?php if($this->input->post('news')){?>
                                <p>Subscribed Successfully.</p>
                            <?php }?>
                        </div><!--/.footer-newsletter-->
                        </div>
                </div><!--/.row-->
            </div><!--/.container-->
        </div><!-- End footer widgets area -->

        <!-- Start footer copyright area -->
        <div class="footer-copyright-area bg-gray">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="copyright text-center">
                            &copy;  <?php echo date('Y')?> Copyrights by TheGlobalScholarship.org
                        </div>
                    </div>
                </div><!--/.row-->
            </div><!--/.container-->
        </div><!--End footer copyright area -->
    </footer><!--End footer area -->


    <!--=========== JS FILE DECLARATION  ==============-->
    <!-- jQuery Latest Version -->
    <!--<script src="<?php echo base_url();?>website_assets/js/jquery-v3.2.1.min.js"></script>-->

      <script src="<?php echo base_url();?>assets/testimonial/js/vendor/vendor.min.js"></script>
    <script src="<?php echo base_url();?>assets/testimonial/js/plugins/plugins.min.js"></script>
    <script src="<?php echo base_url();?>assets/testimonial/js/ajax-contact.js"></script>
    <script src="<?php echo base_url();?>assets/testimonial/js/plugins/aos.js"></script>
    <script src="<?php echo base_url();?>assets/testimonial/js/plugins/waypoints.js"></script>
    <script src="<?php echo base_url();?>assets/testimonial/js/plugins/jquery.selectric.min.js"></script>
    <script src="<?php echo base_url();?>assets/testimonial/js/main.min.js"></script>
    <!-- PopperJS -->
    <script src="<?php echo base_url();?>website_assets/js/popper.min.js"></script>
    <!-- Bootstrap framework JS -->
    <script src="<?php echo base_url();?>website_assets/js/bootstrap.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js"></script>
    <!-- All JS plugins included in this file. -->
    <script src="<?php echo base_url();?>website_assets/js/plugins.js"></script>
    <!-- Main JS file that contents all jQuery Plugins activation. -->
    <script src="<?php echo base_url();?>website_assets/js/main.js"></script>
    <!--<script src="<?php echo base_url();?>website_assets/js/dec.js"></script>-->
    
        <div class='container'>
    <div class="modal modal-xl fade" id="offer-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <!--<div class="modal-header "> <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button> </div>-->
                <div class="modal-body p-0 row">
                    <div class="col-12 col-lg-4 p-0 ad"> <img src="https://www.theglobalscholarship.org/website_assets/images/earn.png" width="100%" height="100%"> </div>
                    <div class="details col-12 col-lg-8 text-center">
                        <div class="heading d-flex">
                            <div class="logo"></div>
                            <div class="off"></div>
                        </div>
                        <h2 id="offer-time">YAYY! WE HAVE UPGRADED!</h2>
                        <p>JOIN OUR REFERRAL PROGRAM</p>
                        <div class="text-muted hurry"><small>EARN WHILE YOU LEARN</small></div>
                        <!--<p><small class="text-muted blink-me"><br /></small></p>-->
                        <p><small class="text-muted"><span class="blink-me">EARN RS. 50 ON EVERY REFERRAL.</span> <br /> REGISTER WITH US TODAY AND START EARNING.<br /></small></p>
                        <div class="mt-2 mb-5 text-center register-modal-button"> <a  href="<?php echo base_url('student-register')?>"><button  align="center" type="button" class="btn booking"><label><strong>REGISTER NOW</label></button></a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .modal,
.fade,
.show {
    /*background-color: lightgray;*/
    padding-left: 0px;
    padding-right: 15px
    opacity: 0.5;
}

.modal{
    /*background-color: lightgray;*/
    z-index: 1000000000;
    padding-top: 75px;
}

.modal-content {
    /*background: transparent;*/
    border: none;
    /*padding: 0 19px*/
}

/*.close {*/
/*    position: relative;*/
/*    top: 48px;*/
/*    left: 13px;*/
/*    z-index: 1;*/
/*    font-size: 30px;*/
/*    font-weight: 100;*/
/*    line-height: 1;*/
/*    color: gray*/
/*}*/

/*.modal-header {*/
/*    border: none*/
/*}*/

.modal-body {
    border: none;
    background-color: white;
    padding-bottom: 5px
}


.heading {
    justify-content: space-between
}

.modal-footer {
    border: none
}

.logo {
    width: 100px;
    height: 100px;
    /*background: url(https://res.cloudinary.com/dxfq3iotg/image/upload/v1576118709/83225325-beauty-spa-logo-design.jpg);*/
    background-size: contain;
    position: relative;
    right: 14px
}

.off {
    margin-top: 25px;
    width: 50px;
    height: 50px;
    /*background: url(https://www.theglobalscholarship.org/website_assets/images/Grab2.png);*/
    background-size: contain
}

.booking {
    background-color: white;
    border: 2px solid lightgray;
    width: 350px;
    border-radius: 0px
    /*animation: animate 1.5s linear infinite;*/
}

.blink-me{
    font-weight:600;
    animation: animate 2.5s linear infinite;
}

.booking:hover {
    background-color: #ECEFF1;
    border: 2px solid black
}

@media (min-width:599px) {
    .modal-dialog {
        max-width: 47rem
    }

    .details {
        /*padding: 0 100px*/
    }

    .off {
        position: absolute;
        bottom: 150px;
        left: 25px
    }
}

@media screen and (max-width: 600px) {
  .ad {
    visibility: hidden;
    clear: both;
    float: left;
    margin: 10px auto 5px 20px;
    width: 28%;
    display: none;
  }
}

@keyframes animate { 
            0% { 
                opacity: 0; 
            } 
  
            50% { 
                opacity: 0.7; 
            } 
  
            100% { 
                opacity: 0; 
            } 
        }
</style>

<script>
// var countDownDate = new Date("Jan 7, 2021 20:00:00").getTime();
// var x = setInterval(function() {
//   var now = new Date().getTime();
//   var distance = countDownDate - now;
//   var days = Math.floor(distance / (1000 * 60 * 60 * 24));
//   var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
//   var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
//   var seconds = Math.floor((distance % (1000 * 60)) / 1000);
//   document.getElementById("offer-timeE").innerHTML = days + "D " + hours + "H "
//   + minutes + "M " + seconds + "S ";
//       if (distance < 0) {
//     clearInterval(x);
//     document.getElementById("offer-timeE").innerHTML = "OOP! You are late..";
//     $('#register-modal-button').hide();
//   }
// }, 1000);

<?php if($this->input->get('rcode') == ''){?>
// $(document).ready(function(){
//     setTimeout(function(){  $("#offer-modal").modal(); }, 5000);
// });
<?php }?>
</script>

    <?php if($this->session->flashdata('proceed')){?>
        <script>
                    $('#exampleModalCenter').modal('show');
        </script>
    <?php }?>
   <?php if(isset($_GET['payment']) && $_GET['payment'] == 'success'){?>
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">The Global Scholarship</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <p style="text-align: center;"><strong>Your registration has been done successfully.</strong></p><br>
          Share On Facebook : 
          
          <div class="fb-share-button" data-href="https://www.theglobalscholarship.org/student-register" data-layout="button" data-size="small"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.theglobalscholarship.org%2Fstudent-register&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Share</a></div> 
        </div>
        <div class="modal-footer">
            <a href="<?php echo base_url('student-login')?>" class="btn btn-success">Click Here To Login</a>
          <button type="button" id="regconfirmclosebtn" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <div id="fb-root"></div>
  <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v6.0"></script>
    <script>
    $(document).ready(function(){
    $("#myModal").modal();
    });
    $('#regconfirmclosebtn').click( function(){
       location.replace('<?php echo base_url();?>'); 
    });
    </script>
    <!--end modal-->
    <?php } ?>
    
    
     <?php if(isset($_GET['payment']) && $_GET['payment'] == 'cancelled'){?>
    <div class="modal fade" id="myModalCancelled" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">The Global Scholarship</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <p style="text-align: center;"><strong>Registration has been cancelled...</strong></p>
        </div>
        <div class="modal-footer">
          <button type="button" id="regcancelclosebtn" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
    <script>
    $(document).ready(function(){
    $("#myModalCancelled").modal();
    });
    $('#regcancelclosebtn').click( function(){
       location.replace('<?php echo base_url();?>'); 
    });
    </script>
    <!--end modal-->
    <?php } ?>
    
    
    
    <?php if(isset($_GET['payment']) && $_GET['payment'] == 'successforindividual'){?>
    <div class="modal fade" id="myModalforIndividual" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">The Global Scholarship</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <p style="text-align: center;"><strong>Your payment has been done successfully. Your Scholarship will be added soon to website.</strong></p>
        </div>
        <div class="modal-footer">
          <button type="button" id="regconfirmclosebtnforindividual" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
    <script>
    $(document).ready(function(){
    $("#myModalforIndividual").modal();
    });
    $('#regconfirmclosebtnforindividual').click( function(){
       location.replace('<?php echo base_url();?>'); 
    });
    </script>
    <!--end modal-->
    <?php } ?>

    <?php if(isset($_GET['payment']) && $_GET['payment'] == 'failed'){?>
        <div class="modal fade" id="myModal2" role="dialog">
            <div class="modal-dialog">
            
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                <h4 class="modal-title">The Global Scholarship</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                <p style="text-align: center;"><strong>Something went wrong, Please try again.</strong></p>
                </div>
                <div class="modal-footer">
                <button type="button" id="regconfirmclosebtnfail" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
            
            </div>
        </div>
    <script>
    $(document).ready(function(){
    $("#myModal2").modal();
    });
    $('#regconfirmclosebtnfail').click( function(){
       location.replace('<?php echo base_url();?>'); 
    });
    </script>
    <!--end modal-->
    <?php } ?>
    
    <?php if($this->uri->segment(1) == '123222122312'){?>
    <!--<div class="modal fade" id="webinar" role="dialog">-->
    <!--        <div class="modal-dialog" style='margin-top: 125px;'>-->
            
            <!-- Modal content-->
    <!--        <div class="modal-content">-->
    <!--            <div class="modal-header">-->
    <!--            <h4 class="modal-title">The Global Scholarship</h4>-->
    <!--            <button type="button" class="close" data-dismiss="modal">&times;</button>-->
    <!--            </div>-->
    <!--            <div class="modal-body">-->
    <!--            <p style="text-align: center;"><strong>The Global Scholarship Webinar on Awareness about Unknown Scholarships. Register to join.</strong></p>-->
    <!--            </div>-->
    <!--            <div class="modal-footer">-->
    <!--            <a target='_blank' style='background-color:green; color:#ffffff' class="btn btn-default" href='https://forms.gle/UU7g8JXTdvm7YY3j8'>Register</a>-->
    <!--            <button type="button" id="regconfirmclosebtnfail" class="btn btn-default" data-dismiss="modal">Close</button>-->
    <!--            </div>-->
    <!--        </div>-->
            
    <!--        </div>-->
    <!--    </div>-->
    <!--<script>-->
    <!--$(document).ready(function(){-->
    <!--$("#webinar").modal();-->
    <!--});-->
    <!--// $('#regconfirmclosebtnfail').click( function(){-->
    <!--//   location.replace('<?php echo base_url();?>'); -->
    <!--// });-->
    <!--</script>-->
    <?php }?>
    
    <?php if($this->uri->segment(1) == 'student-register'){?>
   <div style="top:130px !important" class="modal fade" id="opportunity" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">WAIT!!!!</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <p style="text-align: center;"><strong>You need to read this.. We Have</strong></p>
          <ul align="center">
              <li><strong>1000+ </strong><i class="fa fa-graduation-cap"></i>Scholarships till date</li>
              <li> Sent <strong><i class="fa fa-rupee"></i>26,01,070</strong> worth Scholarships in <?php echo date('Y');?></li>
              <li> Sent <strong>20,000+ </strong> <i class="fa fa-bell"></i>notifications in <?php echo date('Y');?></li>
          </ul>
        </div>
        <div class="modal-footer">
          <button type="button" id="opportunity" class="btn btn-default" data-dismiss="modal"><i class="fa fa-frown-o" aria-hidden="true"></i> Let go</button>
        </div>
      </div>
      
    </div>
  </div>
<?php }?>
    
    <?php if(isset($_GET['payment']) && $_GET['payment'] == 'failedforindividual'){?>
        <div class="modal fade" id="myModal2forindividual" role="dialog">
            <div class="modal-dialog">
            
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                <h4 class="modal-title">The Global Scholarship</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                <p style="text-align: center;"><strong>Something went wrong, Please try again.</strong></p>
                </div>
                <div class="modal-footer">
                <button type="button" id="regconfirmclosebtnfailforindividual" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
            
            </div>
        </div>
    <script>
    $(document).ready(function(){
    $("#myModal2forindividual").modal();
    });
    $('#regconfirmclosebtnfailforindividual').click( function(){
       location.replace('<?php echo base_url();?>'); 
    });
    </script>
    <!--end modal-->
    <?php } ?>
    
    <script type="text/javascript">
        $(document).ready(function(){
            $('#exampleModalCenterforPayment').modal();
            $('#redirectToContributor').modal();
            $('#redirectToInstitute').modal();
            $('#redirectToIndividual').modal();
            $('#reset_password').modal();
        });
    </script>
    <script src="<?php echo base_url();?>website_assets/build/js/intlTelInput-jquery.js"></script>
    <script src="<?php echo base_url();?>website_assets/build/js/utils.js"></script>

<style>
.hide{
    display:none;
}
</style>
<script>
    $(document).ready(function(){
        $("#mobile-number").intlTelInput();
        var input = document.querySelector("#mobile-number"),
        errorMsg = document.querySelector("#error-msg"),
        validMsg = document.querySelector("#valid-msg");

        var errorMap = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];
        var iti = $("#mobile-number").intlTelInput(input, {
          utilsScript: "<?php echo base_url();?>website_assets/build/js/utils.js"
      });
        var reset = function() {
          input.classList.remove("error");
          errorMsg.innerHTML = "";
          errorMsg.classList.add("hide");
          validMsg.classList.add("hide");
      };
      input.addEventListener('change', reset);
      input.addEventListener('keyup', reset);
      $("#mobile-number").keyup(function()
      {
        if($("#mobile-number").val() == ''){
            $("#mobile-number").removeAttr('maxlength');
            $("#mobile-number").css('border-color','red');
        }
        let str = $("#mobile-number").val();
        var input = document.querySelector("#mobile-number"),
        errorMsg = document.querySelector("#error-msg"),
        validMsg = document.querySelector("#valid-msg");
        input.addEventListener('keyup', function() {
          reset();
          if (input.value.trim()) {
            if ($("#mobile-number").intlTelInput("isValidNumber")) {
                var countryCode = $("#mobile-number").intlTelInput("getSelectedCountryData");
                let maxDig = $("#mobile-number").val();
                $("#mobile-number").removeAttr('placeholder');
                $("#mobile-number").attr('maxlength',maxDig.length);
                if($("#mobile-number").val() == ''){
                    $("#mobile-number").removeAttr('maxlength');
                }
                $('#countryCode').val(countryCode.dialCode);
                $("#mobile-number").css('border-color','green');
                validMsg.classList.remove("hide");
            } else {
                $('#mobile-number').on('input', function (event) { 
                    this.value = this.value.replace(/[^0-9]/g, '');
                });
                $("#mobile-number").removeAttr('placeholder');
                input.classList.add("error");
                var errorCode = $("#mobile-number").intlTelInput('getValidationError');
                $("#mobile-number").css('border-color','red');
                errorMsg.innerHTML = errorMap[errorCode];
                errorMsg.classList.remove("hide");
            }
        }
    });
    });

  });
</script>
  <script>
      var regex = new RegExp("(.*?)\.(csv)$");
      function triggerValidation(el) {
        if (!(regex.test(el.value.toLowerCase()))) {
          el.value = '';
          $('#filetypeerror').show();
          $('#filetypeerror').css('opacity','1');
          // var alertBox = document.getElementsById("filetypeerror");
          // alertBox.style.display = alertBox.style.display === 'none' ? '' : 'none';
          // alert('Please select correct file format');
      }
  }
  </script>
  <script >
    window.setTimeout(function() {
        $(".alert").fadeTo(500, 0).slideUp(500, function(){
            $(this).hide();
        });
    }, 6000);
</script>

<style>
  /*.select2-container {
  width: 90% !important;
}

.select2-container .select-all {
    position: absolute;
    top: 6px;
    right: 4px;
    width: 20px;
    height: 20px;
    margin: auto;
    display: block;
    background-size: contain;
    cursor: pointer;
    z-index: 999999;
  }*/
</style>
<script>
 $(document).ready(function() {
   $('.js-example-basic-multiple').select2();
});



// $('.js-example-basic-multiple').select2({
//   placeholder: 'Press CTRL+A for selecr or unselect all options'
// });

// $('.select2[multiple]').siblings('.select2-container').append('<span class="select-all"></span>');

// $(document).on('click', '.select-all', function (e) {
//   selectAllSelect2($(this).siblings('.selection').find('.select2-search__field'));
// });

// $(document).on("keyup", ".select2-search__field", function (e) {
//   var eventObj = window.event ? event : e;
//   if (eventObj.keyCode === 65 && eventObj.ctrlKey)
//      selectAllSelect2($(this));
// });
        
        
// function selectAllSelect2(that) {

//   var selectAll = true;
//   var existUnselected = false;
//   var id = that.parents("span[class*='select2-container']").siblings('select[multiple]').attr('id');
//   var item = $("#" + id);

//   item.find("option").each(function (k, v) {
//       if (!$(v).prop('selected')) {
//           existUnselected = true;
//           return false;
//       }
//   });

//   selectAll = existUnselected ? selectAll : !selectAll;

//   item.find("option").prop('selected', selectAll).trigger('change');
// }



$(document).ready(function () {
    sport();
    noSport();
    $("#sports").prop("disabled", true);
    $('#no-sport').hide();
      $("#sport").change(function () {
        sport();
      });
      $("#no-sport").change(function () {
        noSport();
      });

      function sport(){
        var thisvalue =  $('#sport').val();
        //   alert(thisvalue);
          if(thisvalue == 'on'){
            $("#sports").prop("disabled", false);
            $('#no-sport').show();
            $("#sport").hide();
            $('#no-sport').prop("checked", true);
          }
      }

      function noSport(){
        var thisvalue =  $('#sport').val();
        //   alert(thisvalue);
          if(thisvalue == 'on'){
            $("#sports").prop("disabled", true);
            $('#no-sport').hide();
            $("#sport").show();
            $('#sport').prop("checked", false);
          }
      }
});
</script>
<script>
$(document).ready(function () {
    talent();
    noTalent();
    $("#specialTalent").prop("disabled", true);
    $('#no-talent').hide();
      $("#talent").change(function () {
        talent();
      });
      $("#no-talent").change(function () {
        noTalent();
      });

      function talent(){
        var thisvalue =  $('#talent').val();
        //   alert(thisvalue);
          if(thisvalue == 'on'){
            $("#specialTalent").prop("disabled", false);
            $('#no-talent').show();
            $("#talent").hide();
            $('#no-talent').prop("checked", true);
          }
      }

      function noTalent(){
        var thisvalue =  $('#talent').val();
        //   alert(thisvalue);
          if(thisvalue == 'on'){
            $("#specialTalent").prop("disabled", true);
            $('#no-talent').hide();
            $("#talent").show();
            $('#talent').prop("checked", false);
          }
      }
});



$(document).ready(function(){
$('.cat-2').hide();
    $('#scholarship_category').change(function(){
        var myDropVal = $('#scholarship_category').val();
        if(myDropVal == 'educational'){
            $('#Caste').prop('disabled',false);
            $('#Religion').prop('disabled',false);
            $('#stud_type').prop('disabled',false);
            $('.cat-2').hide();
        }else{
            $('#Caste').prop('disabled',true);
            $('#Religion').prop('disabled',true);
            $('#stud_type').prop('disabled',true);
            $('.cat-2').show();
        }
    });

});
</script>

<style>
    .multiselect-container>li>a>label {
  padding: 4px 20px 3px 20px;
}
</style>
<!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5ed8817de8cea7d4"></script>
<?php if($this->uri->segment(1) == 'student-register' ){?>
    <script>
    // window.onbeforeunload = confirmExit;
    // function confirmExit() {
    //     return "You have attempted to leave this page. Are you sure?";
    // }
    $(document).ready(function(){
      var visit = false;
      var opened = false;
      $('.header-inner').hover(function(){
        visit = true;
      });
      $('.focus').hover(function(){
        // alert(counter);
        if(visit == true && opened == false){
          $("#opportunity").modal('show');
        }
      });

      $('#opportunity').on('shown.bs.modal', function (e) {
       opened=true;
     });
    });
  </script>
<?php }?>
</body>
</html>
