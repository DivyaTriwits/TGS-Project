<!-- Main Content-->
<div class="main-content pt-5 mt-5 mb-5">
	<div class="container fuild">


			<!-- Row -->
			<div class="row">
				<div class="col-lg-12">
					<div class="card">
						<div class="card-body" >
							<div>
								<h6 class="main-content-label mb-1">Account Setting</h6><br>
							</div>
							<div class="row">
								
								<!-- <div class="col-xl-2 col-lg-3 col-md-12 col-sm-12 pb-2">
									<a href="<?php echo base_url('reset-password') ?>" class="btn  btn-secondary  btn-rounded btn-block"style="background-color:#ff7f45;border-color:#ff7f45 ">Reset Password</a>
								</div> -->
								<div class="col-xl-2 col-lg-3 col-md-12 col-sm-12 pb-2">
									<a href="<?php echo base_url('refer-and-earn') ?>" class="btn  btn-secondary  btn-rounded btn-block"style="background-color:#ff7f45;border-color:#ff7f45">Share and Earn</a>
								</div>
								<!-- <div class="col-xl-2 col-lg-3 col-md-12 col-sm-12 pb-2">
									<a href="<?php echo base_url('my-invoice') ?>" class="btn  btn-secondary  btn-rounded btn-block"style="background-color:#ff7f45;border-color:#ff7f45">My Invoice</a>
								</div> -->
								<div class="col-xl-2 col-lg-3 col-md-12 col-sm-12 pb-2">

									<a href="<?php echo base_url('influencer-requests') ?>" class="btn  btn-secondary  btn-rounded btn-block"style="background-color:#ff7f45;border-color:#ff7f45">Redeem Requests</a>
								</div>
								<!-- <div class="col-xl-2 col-lg-3 col-md-12 col-sm-12 pb-2">
									<a href="<?php echo base_url('login-details') ?>"class="btn  btn-secondary  btn-rounded btn-block"style="background-color:#ff7f45;border-color:#ff7f45 ">View Login Details</a>
								</div> -->
								<div class="col-xl-2 col-lg-3 col-md-12 col-sm-12 pb-2">
									<a href="<?php echo base_url('influencer-login') ?>"class="btn  btn-secondary  btn-rounded btn-block"style="background-color:#ff7f45;border-color:#ff7f45 ">Signout</a>
								</div>
								
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- Row -->
			<div class="row">
				<!-- <a data-target="#trackorder" class="nav-link" data-toggle="tab" role="tablist"><i class="fe fe-truck icon1"></i> Track Order</a> -->
				<div class="col-lg-12 col-md-12">
					<!-- <div class="card"> -->
						<div class="card" id="buttons">
							<div class="card-body">
								<div>
									<h6 class="main-content-label mb-1">Our Social Media</h6>

								</div>
								<!-- <div class="text-wrap"> -->
									<div class="example">
											<!-- <div class="btn-list">
											</div> -->
											<div id="social">
												
												<div class="btn-list">
													<div class="row">
														<div class="col-md-12">

															<a target="_blank" 
															href="https://www.facebook.com/theglobalscholarship"
															class="fb-xfbml-parse-ignore"
															style="margin-right: 15px"> <button type="button" class="btn ripple btn-primary">
																<i class="fe fe-facebook"></i>
															</button></a>
															<a href="https://instagram.com/the_global_scholarship" target="_blank" style="margin-right: 15px">
																<button type="button" class="btn ripple btn-pink">
																	<i class="fe fe-instagram"></i>
																</button>
															</a>
															<a href="https://www.youtube.com/channel/UCz9Z-M9gLDzCYNAxvDxu4Rw" target="_blank" style="margin-right: 15px">
																<button type="button" class="btn ripple " style="background-color: #FF0000">
																	<i class="typcn typcn-social-youtube"></i>
																</button>
															</a>
															<
											<!-- <a  href="">
												<button type="button" class="btn ripple btn-info" id="btn-share">Share</button>
											</a> -->
										</div>
									</div>
								</div>
							</div>
							<br>
							
						</div>
						
						<!-- </div> -->

					</div>
				</div>
				<!-- </div> -->
			</div>
		</div>
	
	</div>
</div>

<!-- Row -->




<?php if ($this->session->flashdata('update-success')) { ?>		
	<Script>
		swal({
			title: 'Well done!',
			text: 'Your  Message successfully Sent....!',
			type: 'success',
			timer: 3000,
			showConfirmButton: false
		});
	</Script>
	<?php
} ?>

<script>
	$(document).ready(function() {
		$('#contactForm').bootstrapValidator({
        // To use feedback icons, ensure that you use Bootstrap v3.1.0 or later
        feedbackIcons: {
        	valid: 'glyphicon glyphicon-ok',
        	invalid: 'glyphicon glyphicon-remove',
        	validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
        	
        	name: {
        		validators: {
        			notEmpty: {
        				message: 'Name is required'
        			},

        			// regexp: {
        			// 	regexp: /[0-9]/,
        			// 	message: ' <br >The conatct number can only consist of digits'
        			// }
        		}
        	},
        	number: {
        		validators: {
        			notEmpty: {
        				message: 'The contact number is required'
        			},
        			stringLength: {
        				min: 10,acc
        				max: 10,
        				message: 'The contact number. must be 10 digits'
        			},
        			regexp: {
        				regexp: /[0-9]/,
        				message: ' <br >The conatct number can only consist of digits'
        			}
        		}
        	}          
        }
    }).on('success.form.bv', function(e) {
    	$(this)[0].submit();

    });                             
});
</script>

